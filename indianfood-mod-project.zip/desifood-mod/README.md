# Indian Food (Fabric, Minecraft 1.20.1)

Bharat ka swaad, Minecraft mein. **42 naye items + Tandoor block**, sab kuch naye texture ke saath (koi purana vanilla texture nahi). Har khaane ka apna effect hai, aur khate waqt particles bhi aate hain (teekha = aag, meetha = dil, chai = bhaap, biryani/thali = totem sparkle).

## Kaise chalaye

1. JDK 17 install karo.
2. Is folder mein: `./gradlew build` (Windows pe `gradlew.bat build`).
3. `build/libs/indianfood-1.0.0.jar` ko `.minecraft/mods` mein daalo.
4. Fabric Loader (0.14.21+) aur **Fabric API** (1.20.1 wala) bhi mods folder mein hona chahiye.
5. Test: `./gradlew runClient`. Creative mein "Indian Food" tab kholo, sab items wahin hain.

Language English ya Hindi (हिन्दी, `hi_in`) dono mein hai.

## Tandoor

Craft: 7 brick + 1 campfire. Right-click karo (aur doosre haath mein extra cheez):

| Haath mein | Doosre haath mein | Milta hai |
|---|---|---|
| Atta Dough | Ghee | Butter Naan |
| Atta Dough | kuch nahi | Naan |
| Raw Chicken | Lal Mirch | Tandoori Chicken |
| Paneer | Lal Mirch | Paneer Tikka |
| Potato | kuch nahi | Baked Potato |

## Khaane aur effects

| Item | Effects |
|---|---|
| Jalebi | Haste 30s, Speed 10s |
| Gulab Jamun | Regeneration 6s, Absorption 30s |
| Laddu | Strength 20s |
| Rasgulla | Jump Boost II 30s, Slow Falling 15s |
| Kheer (bowl wapas) | Regeneration 8s, Resistance 20s |
| Kulfi | Fire Resistance 60s, Haste 15s |
| Samosa | Speed 15s |
| Pani Puri | Speed II 10s, 10% chance Nausea (jaldi khaate hain) |
| Dhokla | Jump Boost 30s |
| Vada Pav | Speed 30s, teekha |
| Pav Bhaji | Speed 20s, Haste II 30s, teekha |
| Roti, Naan | bas pet bharta hai |
| Butter Naan | Resistance 15s |
| Aloo Paratha | Strength 30s |
| Paneer Tikka | Strength 30s, teekha |
| Tandoori Chicken | Strength 30s, Resistance 15s, teekha |
| Butter Chicken (bowl wapas) | Regeneration 10s, Strength 20s |
| Paneer Butter Masala (bowl wapas) | Regeneration 10s, Absorption II 60s |
| Dal Tadka (bowl wapas) | Regeneration 5s, Resistance 30s |
| Rajma Chawal (bowl wapas) | Health Boost 60s |
| Chole Bhature | Strength 30s, Resistance 30s, Slowness 20s (bhaari khana) |
| Idli | Regeneration 3s |
| Dosa | Speed 15s |
| Masala Dosa | Speed 30s, Haste 15s |
| Biryani (bowl wapas) | Strength 30s, Regeneration 10s, Speed 20s, Absorption 60s |
| Thali | Regeneration II 20s, Resistance 60s, Strength 60s, Health Boost II 120s (dheere khaao, hamesha khaa sakte ho) |
| Masala Chai (bottle wapas) | Speed 60s, Haste 60s |
| Sweet Lassi (bottle wapas) | Absorption 60s, Fire Resistance 30s |

"Teekha" wale khaane se kuch second ke liye aap jalte hue dikhte ho, par Fire Resistance automatically lagta hai, to damage nahi hota.
Non-veg: Tandoori Chicken, Butter Chicken, Biryani.

## Ingredients aur recipes

Sab recipes shapeless crafting hain (Tandoor ko chhodkar). Roti ko furnace / smoker / campfire mein atta dough pakane se bhi bana sakte ho.

| Ingredient | Recipe |
|---|---|
| Atta | 3 wheat -> 2 |
| Atta Dough | 2 atta + water bucket -> 4 |
| Besan | 2 wheat + yellow dye -> 3 |
| Chawal | 3 wheat seeds -> 2 |
| Haldi | carrot + yellow dye -> 2 |
| Lal Mirch | beetroot + red dye -> 2 |
| Jeera | wheat seeds + cocoa beans -> 2 |
| Elaichi | melon seeds + lime dye -> 2 |
| Garam Masala | jeera + lal mirch + haldi + elaichi -> 2 |
| Ghee / Paneer / Dahi | milk bucket + coal / sweet berries / sugar -> 3 (bucket wapas) |
| Chai Patti | fern + cocoa beans -> 2 |

Masale (haldi, lal mirch, jeera, elaichi, chai patti, besan, chawal) village ke ghar ke chests mein bhi milte hain.

Khaane ki recipes (sab shapeless, items kisi bhi jagah rakho):

- Samosa: dough + baked potato + garam masala (2)
- Jalebi: besan + sugar + ghee (3)
- Gulab Jamun: paneer + sugar + ghee (3)
- Laddu: besan + ghee + 2 sugar (3)
- Rasgulla: paneer + sugar + water bucket (3)
- Kheer: chawal + milk bucket + sugar + bowl
- Kulfi: milk bucket + sugar + elaichi + snowball + stick (2)
- Naan: dough + dahi. Butter Naan: naan + ghee
- Aloo Paratha: 2 dough + baked potato + ghee (2)
- Pani Puri: dough + jeera + lal mirch + water bucket (4)
- Dhokla: besan + dahi + haldi (2)
- Vada Pav: bread + baked potato + lal mirch + besan (2)
- Pav Bhaji: 2 bread + baked potato + beetroot + ghee (2)
- Paneer Tikka: 2 paneer + lal mirch + stick (2)
- Tandoori Chicken: cooked chicken + lal mirch + dahi + garam masala
- Butter Chicken: cooked chicken + ghee + garam masala + dahi + bowl
- Paneer Butter Masala: bowl + paneer + ghee + garam masala + dahi
- Dal Tadka: bowl + 2 pumpkin seeds + haldi + jeera + ghee
- Rajma Chawal: bowl + chawal + beetroot + garam masala
- Chole Bhature: dough + 2 pumpkin seeds + garam masala + ghee
- Idli: 2 chawal + dahi (3)
- Dosa: 2 chawal + dahi + ghee (2)
- Masala Dosa: dosa + baked potato + garam masala
- Biryani: bowl + 2 chawal + cooked chicken + garam masala
- Thali: roti + dal tadka + rajma chawal + gulab jamun
- Masala Chai: milk bucket + chai patti + sugar + elaichi + 3 glass bottles (3)
- Sweet Lassi: 2 dahi + sugar + 2 glass bottles (2)

## Apne hisaab se badalna

- Effects aur hunger: `src/main/java/com/desifood/ModItems.java` (ek line = ek item).
- Textures: `tools/gen_textures.py` chalao (`python3 tools/gen_textures.py .`), ya seedha PNG edit karo (`src/main/resources/assets/desifood/textures`).
- Naam, tooltips, recipes: `tools/gen_data.py` (ya seedha JSON files).
