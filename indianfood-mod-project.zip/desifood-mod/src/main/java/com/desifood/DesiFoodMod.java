package com.desifood;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DesiFoodMod implements ModInitializer {
	public static final String MOD_ID = "desifood";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return new Identifier(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModItems.init();
		ModBlocks.init();
		ModItemGroup.init();
		ModLoot.init();
		LOGGER.info("Indian Food loaded: {} items + Tandoor. Bhookh lag gayi? Chalo khaate hain!", ModItems.ALL.size());
	}
}
