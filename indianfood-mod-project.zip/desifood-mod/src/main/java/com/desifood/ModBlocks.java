package com.desifood;

import com.desifood.block.TandoorBlock;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

public final class ModBlocks {
	public static final Block TANDOOR = Registry.register(Registries.BLOCK, DesiFoodMod.id("tandoor"),
			new TandoorBlock(FabricBlockSettings.create()
					.mapColor(MapColor.ORANGE)
					.strength(2.5f, 6.0f)
					.sounds(BlockSoundGroup.STONE)
					.requiresTool()
					.luminance(state -> 10)));

	public static final Item TANDOOR_ITEM = Registry.register(Registries.ITEM, DesiFoodMod.id("tandoor"),
			new BlockItem(TANDOOR, new FabricItemSettings()));

	private ModBlocks() {
	}

	public static void init() {
		// Touching this class registers the block and its item.
	}
}
