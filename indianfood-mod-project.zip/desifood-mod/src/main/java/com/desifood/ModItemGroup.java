package com.desifood;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public final class ModItemGroup {
	public static final ItemGroup DESI_FOOD = Registry.register(Registries.ITEM_GROUP, DesiFoodMod.id("main"),
			FabricItemGroup.builder()
					.icon(() -> new ItemStack(ModItems.BIRYANI))
					.displayName(Text.translatable("itemGroup.desifood.main"))
					.entries((context, entries) -> {
						entries.add(ModBlocks.TANDOOR_ITEM);
						for (Item item : ModItems.ALL) {
							entries.add(item);
						}
					})
					.build());

	private ModItemGroup() {
	}

	public static void init() {
		// Touching this class registers the creative tab.
	}
}
