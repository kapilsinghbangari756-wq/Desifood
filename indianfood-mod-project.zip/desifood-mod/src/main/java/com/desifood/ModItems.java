package com.desifood;

import com.desifood.item.DesiFoodItem;
import com.desifood.item.Flavor;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {
	/** Every item of the mod in creative-tab order. Must stay the first field. */
	public static final List<Item> ALL = new ArrayList<>();

	// ------------------------------------------------------------------ sweets
	public static final Item JALEBI = food("jalebi", Spec.of(4, 0.5f).flavor(Flavor.SWEET)
			.fx(StatusEffects.HASTE, 30, 0).fx(StatusEffects.SPEED, 10, 0));
	public static final Item GULAB_JAMUN = food("gulab_jamun", Spec.of(4, 0.5f).flavor(Flavor.SWEET)
			.fx(StatusEffects.REGENERATION, 6, 0).fx(StatusEffects.ABSORPTION, 30, 0));
	public static final Item LADDU = food("laddu", Spec.of(5, 0.7f).flavor(Flavor.SWEET)
			.fx(StatusEffects.STRENGTH, 20, 0));
	public static final Item RASGULLA = food("rasgulla", Spec.of(4, 0.5f).flavor(Flavor.SWEET)
			.fx(StatusEffects.JUMP_BOOST, 30, 1).fx(StatusEffects.SLOW_FALLING, 15, 0));
	public static final Item KHEER = food("kheer", Spec.of(7, 0.8f).flavor(Flavor.SWEET).bowl()
			.fx(StatusEffects.REGENERATION, 8, 0).fx(StatusEffects.RESISTANCE, 20, 0));
	public static final Item KULFI = food("kulfi", Spec.of(3, 0.4f).flavor(Flavor.SWEET)
			.fx(StatusEffects.FIRE_RESISTANCE, 60, 0).fx(StatusEffects.HASTE, 15, 0));

	// ------------------------------------------------------------------ snacks
	public static final Item SAMOSA = food("samosa", Spec.of(5, 0.6f)
			.fx(StatusEffects.SPEED, 15, 0));
	public static final Item PANI_PURI = food("pani_puri", Spec.of(2, 0.3f).snack().eat(10)
			.fx(StatusEffects.SPEED, 10, 1).fx(StatusEffects.NAUSEA, 10, 0, 0.1f));
	public static final Item DHOKLA = food("dhokla", Spec.of(5, 0.6f)
			.fx(StatusEffects.JUMP_BOOST, 30, 0));
	public static final Item VADA_PAV = food("vada_pav", Spec.of(7, 0.8f).flavor(Flavor.SPICY)
			.fx(StatusEffects.SPEED, 30, 0));
	public static final Item PAV_BHAJI = food("pav_bhaji", Spec.of(9, 0.9f).flavor(Flavor.SPICY)
			.fx(StatusEffects.SPEED, 20, 0).fx(StatusEffects.HASTE, 30, 1));

	// ------------------------------------------------------------------ breads
	public static final Item ROTI = food("roti", Spec.of(5, 0.6f));
	public static final Item NAAN = food("naan", Spec.of(6, 0.7f));
	public static final Item BUTTER_NAAN = food("butter_naan", Spec.of(8, 0.9f)
			.fx(StatusEffects.RESISTANCE, 15, 0));
	public static final Item ALOO_PARATHA = food("aloo_paratha", Spec.of(8, 0.8f)
			.fx(StatusEffects.STRENGTH, 30, 0));

	// ------------------------------------------------------------------ mains
	public static final Item PANEER_TIKKA = food("paneer_tikka", Spec.of(7, 0.8f).flavor(Flavor.SPICY)
			.fx(StatusEffects.STRENGTH, 30, 0));
	public static final Item TANDOORI_CHICKEN = food("tandoori_chicken", Spec.of(10, 0.9f).flavor(Flavor.SPICY)
			.fx(StatusEffects.STRENGTH, 30, 0).fx(StatusEffects.RESISTANCE, 15, 0));
	public static final Item BUTTER_CHICKEN = food("butter_chicken", Spec.of(10, 0.9f).bowl()
			.fx(StatusEffects.REGENERATION, 10, 0).fx(StatusEffects.STRENGTH, 20, 0));
	public static final Item PANEER_BUTTER_MASALA = food("paneer_butter_masala", Spec.of(9, 0.9f).bowl()
			.fx(StatusEffects.REGENERATION, 10, 0).fx(StatusEffects.ABSORPTION, 60, 1));
	public static final Item DAL_TADKA = food("dal_tadka", Spec.of(8, 0.8f).bowl()
			.fx(StatusEffects.REGENERATION, 5, 0).fx(StatusEffects.RESISTANCE, 30, 0));
	public static final Item RAJMA_CHAWAL = food("rajma_chawal", Spec.of(9, 0.8f).bowl()
			.fx(StatusEffects.HEALTH_BOOST, 60, 0));
	public static final Item CHOLE_BHATURE = food("chole_bhature", Spec.of(10, 1.0f)
			.fx(StatusEffects.STRENGTH, 30, 0).fx(StatusEffects.RESISTANCE, 30, 0).fx(StatusEffects.SLOWNESS, 20, 0));

	// ------------------------------------------------------------------ south indian
	public static final Item IDLI = food("idli", Spec.of(3, 0.5f)
			.fx(StatusEffects.REGENERATION, 3, 0));
	public static final Item DOSA = food("dosa", Spec.of(6, 0.7f)
			.fx(StatusEffects.SPEED, 15, 0));
	public static final Item MASALA_DOSA = food("masala_dosa", Spec.of(9, 0.9f)
			.fx(StatusEffects.SPEED, 30, 0).fx(StatusEffects.HASTE, 15, 0));

	// ------------------------------------------------------------------ feasts
	public static final Item BIRYANI = food("biryani", Spec.of(12, 1.2f).flavor(Flavor.FEAST).bowl().eat(40)
			.fx(StatusEffects.STRENGTH, 30, 0).fx(StatusEffects.REGENERATION, 10, 0)
			.fx(StatusEffects.SPEED, 20, 0).fx(StatusEffects.ABSORPTION, 60, 0));
	public static final Item THALI = food("thali", Spec.of(20, 1.2f).flavor(Flavor.FEAST).stack(4).eat(64).always()
			.fx(StatusEffects.REGENERATION, 20, 1).fx(StatusEffects.RESISTANCE, 60, 0)
			.fx(StatusEffects.STRENGTH, 60, 0).fx(StatusEffects.HEALTH_BOOST, 120, 1));

	// ------------------------------------------------------------------ drinks
	public static final Item CHAI = food("chai", Spec.of(2, 0.4f).flavor(Flavor.DRINK).bottle().always()
			.fx(StatusEffects.SPEED, 60, 0).fx(StatusEffects.HASTE, 60, 0));
	public static final Item LASSI = food("lassi", Spec.of(3, 0.4f).flavor(Flavor.DRINK).bottle().always()
			.fx(StatusEffects.ABSORPTION, 60, 0).fx(StatusEffects.FIRE_RESISTANCE, 30, 0));

	// ------------------------------------------------------------------ ingredients
	public static final Item ATTA = plain("atta");
	public static final Item ATTA_DOUGH = plain("atta_dough");
	public static final Item BESAN = plain("besan");
	public static final Item CHAWAL = plain("chawal");
	public static final Item HALDI = plain("haldi");
	public static final Item LAL_MIRCH = plain("lal_mirch");
	public static final Item JEERA = plain("jeera");
	public static final Item ELAICHI = plain("elaichi");
	public static final Item GARAM_MASALA = plain("garam_masala");
	public static final Item GHEE = plain("ghee");
	public static final Item PANEER = plain("paneer");
	public static final Item DAHI = plain("dahi");
	public static final Item CHAI_PATTI = plain("chai_patti");

	private ModItems() {
	}

	public static void init() {
		// Touching this class registers everything above.
	}

	private static Item plain(String id) {
		return register(id, new Item(new FabricItemSettings()));
	}

	private static Item food(String id, Spec s) {
		FoodComponent.Builder builder = new FoodComponent.Builder()
				.hunger(s.hunger)
				.saturationModifier(s.saturation);
		if (s.always) {
			builder.alwaysEdible();
		}
		if (s.snack) {
			builder.snack();
		}
		for (Fx fx : s.effects) {
			builder.statusEffect(new StatusEffectInstance(fx.effect(), fx.seconds() * 20, fx.amplifier()), fx.chance());
		}
		Item.Settings settings = new FabricItemSettings().maxCount(s.stack).food(builder.build());
		return register(id, new DesiFoodItem(settings, s.flavor, s.container, s.eatTicks));
	}

	private static Item register(String id, Item item) {
		ALL.add(item);
		return Registry.register(Registries.ITEM, DesiFoodMod.id(id), item);
	}

	private record Fx(StatusEffect effect, int seconds, int amplifier, float chance) {
	}

	/** Small fluent description of a food, so the table above stays readable. */
	private static final class Spec {
		final int hunger;
		final float saturation;
		Flavor flavor = Flavor.SAVORY;
		int stack = 64;
		Item container = null;
		int eatTicks = 32;
		boolean always = false;
		boolean snack = false;
		final List<Fx> effects = new ArrayList<>();

		private Spec(int hunger, float saturation) {
			this.hunger = hunger;
			this.saturation = saturation;
		}

		static Spec of(int hunger, float saturation) {
			return new Spec(hunger, saturation);
		}

		Spec flavor(Flavor flavor) {
			this.flavor = flavor;
			return this;
		}

		Spec stack(int count) {
			this.stack = count;
			return this;
		}

		Spec bowl() {
			this.container = Items.BOWL;
			this.stack = 16;
			return this;
		}

		Spec bottle() {
			this.container = Items.GLASS_BOTTLE;
			this.stack = 16;
			return this;
		}

		Spec eat(int ticks) {
			this.eatTicks = ticks;
			return this;
		}

		Spec always() {
			this.always = true;
			return this;
		}

		Spec snack() {
			this.snack = true;
			return this;
		}

		Spec fx(StatusEffect effect, int seconds, int amplifier) {
			return fx(effect, seconds, amplifier, 1.0f);
		}

		Spec fx(StatusEffect effect, int seconds, int amplifier, float chance) {
			this.effects.add(new Fx(effect, seconds, amplifier, chance));
			return this;
		}
	}
}
