package com.desifood;

import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.loot.LootPool;
import net.minecraft.item.Item;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.entry.LootPoolEntry;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.util.Identifier;

import java.util.Set;

/** Spices turn up in village house chests, so you can start cooking without crafting everything. */
public final class ModLoot {
	private static final Set<Identifier> VILLAGE_CHESTS = Set.of(
			new Identifier("minecraft", "chests/village/village_plains_house"),
			new Identifier("minecraft", "chests/village/village_savanna_house"),
			new Identifier("minecraft", "chests/village/village_desert_house"),
			new Identifier("minecraft", "chests/village/village_taiga_house"),
			new Identifier("minecraft", "chests/village/village_snowy_house")
	);

	private ModLoot() {
	}

	public static void init() {
		LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
			if (!source.isBuiltin() || !VILLAGE_CHESTS.contains(id)) {
				return;
			}
			LootPool.Builder pool = LootPool.builder()
					.rolls(UniformLootNumberProvider.create(1, 3))
					.with(spice(ModItems.HALDI, 4))
					.with(spice(ModItems.LAL_MIRCH, 4))
					.with(spice(ModItems.JEERA, 3))
					.with(spice(ModItems.ELAICHI, 2))
					.with(spice(ModItems.CHAI_PATTI, 3))
					.with(spice(ModItems.BESAN, 2))
					.with(spice(ModItems.CHAWAL, 3));
			tableBuilder.pool(pool);
		});
	}

	private static LootPoolEntry.Builder<?> spice(Item item, int weight) {
		return ItemEntry.builder(item)
				.weight(weight)
				.apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(1, 4)));
	}
}
