package com.desifood.block;

import com.desifood.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.List;

/**
 * The Tandoor: a glowing clay oven. Right-click it with an ingredient (and, for
 * some dishes, a second ingredient in your other hand) to cook instantly.
 */
public class TandoorBlock extends HorizontalFacingBlock {

	/** input in the used hand, optional extra in the other hand, resulting dish. */
	private record Cooking(Item input, Item extra, Item output) {
	}

	private static final List<Cooking> COOKING = List.of(
			new Cooking(ModItems.ATTA_DOUGH, ModItems.GHEE, ModItems.BUTTER_NAAN),
			new Cooking(ModItems.ATTA_DOUGH, null, ModItems.NAAN),
			new Cooking(Items.CHICKEN, ModItems.LAL_MIRCH, ModItems.TANDOORI_CHICKEN),
			new Cooking(ModItems.PANEER, ModItems.LAL_MIRCH, ModItems.PANEER_TIKKA),
			new Cooking(Items.POTATO, null, Items.BAKED_POTATO)
	);

	public TandoorBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH));
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
	}

	@Override
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		ItemStack held = player.getStackInHand(hand);
		ItemStack other = player.getStackInHand(hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND);

		for (Cooking cooking : COOKING) {
			if (!held.isOf(cooking.input())) {
				continue;
			}
			if (cooking.extra() != null && !other.isOf(cooking.extra())) {
				continue;
			}
			if (world.isClient) {
				return ActionResult.SUCCESS;
			}

			if (!player.getAbilities().creativeMode) {
				held.decrement(1);
				if (cooking.extra() != null) {
					other.decrement(1);
				}
			}
			ItemStack out = new ItemStack(cooking.output());
			if (!player.getInventory().insertStack(out)) {
				player.dropItem(out, false);
			}

			world.playSound(null, pos, SoundEvents.BLOCK_CAMPFIRE_CRACKLE, SoundCategory.BLOCKS, 1.0f, 1.0f);
			if (world instanceof ServerWorld serverWorld) {
				serverWorld.spawnParticles(ParticleTypes.FLAME, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
						12, 0.2, 0.1, 0.2, 0.02);
				serverWorld.spawnParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5,
						8, 0.2, 0.1, 0.2, 0.01);
			}
			return ActionResult.CONSUME;
		}
		return ActionResult.PASS;
	}

	@Override
	public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
		double x = pos.getX() + 0.5;
		double y = pos.getY() + 1.0;
		double z = pos.getZ() + 0.5;
		if (random.nextInt(4) == 0) {
			world.addParticle(ParticleTypes.FLAME, x + (random.nextDouble() - 0.5) * 0.4, y, z + (random.nextDouble() - 0.5) * 0.4,
					0.0, 0.02, 0.0);
		}
		if (random.nextInt(3) == 0) {
			world.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, x + (random.nextDouble() - 0.5) * 0.3, y + 0.1, z + (random.nextDouble() - 0.5) * 0.3,
					0.0, 0.06, 0.0);
		}
		if (random.nextInt(12) == 0) {
			world.playSound(x, y, z, SoundEvents.BLOCK_CAMPFIRE_CRACKLE, SoundCategory.BLOCKS,
					0.4f + random.nextFloat() * 0.4f, 0.6f + random.nextFloat() * 0.7f, false);
		}
	}
}
