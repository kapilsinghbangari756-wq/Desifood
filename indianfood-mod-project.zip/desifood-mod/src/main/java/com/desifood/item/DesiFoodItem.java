package com.desifood.item;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

/**
 * A food or drink with a flavour (particle burst), optional container that is
 * handed back (bowl / glass bottle), a custom eating time and a tooltip line.
 */
public class DesiFoodItem extends Item {
	private final Flavor flavor;
	private final Item container;
	private final int eatTicks;
	private final boolean drink;

	public DesiFoodItem(Settings settings, Flavor flavor, Item container, int eatTicks) {
		super(settings);
		this.flavor = flavor;
		this.container = container;
		this.eatTicks = eatTicks;
		this.drink = flavor == Flavor.DRINK;
	}

	@Override
	public int getMaxUseTime(ItemStack stack) {
		return eatTicks;
	}

	@Override
	public UseAction getUseAction(ItemStack stack) {
		return drink ? UseAction.DRINK : UseAction.EAT;
	}

	@Override
	public SoundEvent getEatSound() {
		return drink ? getDrinkSound() : super.getEatSound();
	}

	@Override
	public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
		boolean creative = user instanceof PlayerEntity p && p.getAbilities().creativeMode;
		ItemStack result = super.finishUsing(stack, world, user);

		if (!world.isClient) {
			if (flavor == Flavor.SPICY) {
				// Teekha! Looks like you're on fire, but fire resistance keeps you safe.
				user.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 200, 0));
				user.setOnFireFor(2);
			}
			if (world instanceof ServerWorld serverWorld) {
				serverWorld.spawnParticles(flavor.particle, user.getX(), user.getBodyY(0.8), user.getZ(),
						flavor.count, 0.35, 0.35, 0.35, 0.03);
			}
		}

		if (container != null && !creative) {
			if (result.isEmpty()) {
				return new ItemStack(container);
			}
			if (user instanceof PlayerEntity player) {
				ItemStack back = new ItemStack(container);
				if (!player.getInventory().insertStack(back)) {
					player.dropItem(back, false);
				}
			}
		}
		return result;
	}

	@Override
	public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
		tooltip.add(Text.translatable(this.getTranslationKey() + ".tooltip").formatted(Formatting.GOLD, Formatting.ITALIC));
	}
}
