package com.desifood.item;

import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

/** Decides which particle burst plays around the player after eating. */
public enum Flavor {
	SAVORY(ParticleTypes.HAPPY_VILLAGER, 8),
	SWEET(ParticleTypes.HEART, 6),
	SPICY(ParticleTypes.FLAME, 14),
	DRINK(ParticleTypes.CLOUD, 10),
	FEAST(ParticleTypes.TOTEM_OF_UNDYING, 30);

	public final ParticleEffect particle;
	public final int count;

	Flavor(ParticleEffect particle, int count) {
		this.particle = particle;
		this.count = count;
	}
}
