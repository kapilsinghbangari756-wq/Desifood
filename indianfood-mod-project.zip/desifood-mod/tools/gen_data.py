#!/usr/bin/env python3
"""Generates models, blockstate, lang files, recipes, loot table and tags for Desi Food."""
import json
import os
import sys

ROOT = sys.argv[1]
RES = os.path.join(ROOT, "src/main/resources")
ASSETS = os.path.join(RES, "assets/desifood")
DATA = os.path.join(RES, "data/desifood")


def write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write("\n")


# id: (English name, Hindi name, English tooltip (Hinglish) or None, Hindi tooltip or None)
FOODS = {
    "jalebi": ("Jalebi", "जलेबी", "Meethi, rassili energy! Haste + Speed.", "मीठी, रसीली ताकत! हेस्ट और स्पीड।"),
    "gulab_jamun": ("Gulab Jamun", "गुलाब जामुन", "Chaashni mein dooba, dil jeetne wala. Regeneration + Absorption.", "चाशनी में डूबा, दिल जीतने वाला। रीजनरेशन और एब्ज़ॉर्प्शन।"),
    "laddu": ("Laddu", "लड्डू", "Pehelwan wali taakat! Strength.", "पहलवान वाली ताकत! स्ट्रेंथ।"),
    "rasgulla": ("Rasgulla", "रसगुल्ला", "Spongy aur halka. Jump Boost + Slow Falling.", "स्पंजी और हल्का। जम्प बूस्ट और स्लो फॉलिंग।"),
    "kheer": ("Kheer", "खीर", "Dadi wali kheer. Regeneration + Resistance.", "दादी वाली खीर। रीजनरेशन और रेसिस्टेंस।"),
    "kulfi": ("Kulfi", "कुल्फी", "Thandi thandi! Fire Resistance + Haste.", "ठंडी ठंडी! फायर रेसिस्टेंस और हेस्ट।"),
    "samosa": ("Samosa", "समोसा", "Crispy aur teekha! Speed.", "कुरकुरा और चटपटा! स्पीड।"),
    "pani_puri": ("Pani Puri", "पानी पूरी", "Kabhi kabhi pet gadbad bhi ho jaata hai! Speed (kabhi Nausea).", "कभी-कभी पेट गड़बड़ भी हो जाता है! स्पीड (कभी मितली)।"),
    "dhokla": ("Dhokla", "ढोकला", "Gujarati halka-phulka. Jump Boost.", "गुजराती हल्का-फुल्का। जम्प बूस्ट।"),
    "vada_pav": ("Vada Pav", "वड़ा पाव", "Mumbai ka burger. Speed.", "मुंबई का बर्गर। स्पीड।"),
    "pav_bhaji": ("Pav Bhaji", "पाव भाजी", "Mumbai ka swaad! Speed + Haste.", "मुंबई का स्वाद! स्पीड और हेस्ट।"),
    "roti": ("Roti", "रोटी", "Ghar ki seedhi-saadi roti.", "घर की सीधी-सादी रोटी।"),
    "naan": ("Naan", "नान", "Tandoor ka garam naan.", "तंदूर का गरम नान।"),
    "butter_naan": ("Butter Naan", "बटर नान", "Makkhan se bhara! Resistance.", "मक्खन से भरा! रेसिस्टेंस।"),
    "aloo_paratha": ("Aloo Paratha", "आलू पराठा", "Subah ka sabse bada hero. Strength.", "सुबह का सबसे बड़ा हीरो। स्ट्रेंथ।"),
    "paneer_tikka": ("Paneer Tikka", "पनीर टिक्का", "Angaaron pe sika, teekha! Strength.", "अंगारों पर सिका, तीखा! स्ट्रेंथ।"),
    "tandoori_chicken": ("Tandoori Chicken", "तंदूरी चिकन", "Garam masale ka dhamaka! Strength + Resistance.", "गरम मसाले का धमाका! स्ट्रेंथ और रेसिस्टेंस।"),
    "butter_chicken": ("Butter Chicken", "बटर चिकन", "Makhani gravy, naan ke saath best. Regeneration + Strength.", "मखनी ग्रेवी, नान के साथ बेस्ट। रीजनरेशन और स्ट्रेंथ।"),
    "paneer_butter_masala": ("Paneer Butter Masala", "पनीर बटर मसाला", "Shahi gravy! Regeneration + Absorption.", "शाही ग्रेवी! रीजनरेशन और एब्ज़ॉर्प्शन।"),
    "dal_tadka": ("Dal Tadka", "दाल तड़का", "Ghar ka comfort food. Regeneration + Resistance.", "घर का कम्फर्ट फूड। रीजनरेशन और रेसिस्टेंस।"),
    "rajma_chawal": ("Rajma Chawal", "राजमा चावल", "Sunday ka mood. Health Boost.", "संडे का मूड। हेल्थ बूस्ट।"),
    "chole_bhature": ("Chole Bhature", "छोले भटूरे", "Bhaari khana! Strength + Resistance, par Slowness bhi.", "भारी खाना! स्ट्रेंथ और रेसिस्टेंस, पर स्लोनेस भी।"),
    "idli": ("Idli", "इडली", "Steam wali sehat. Regeneration.", "भाप वाली सेहत। रीजनरेशन।"),
    "dosa": ("Dosa", "डोसा", "Crispy aur patla. Speed.", "कुरकुरा और पतला। स्पीड।"),
    "masala_dosa": ("Masala Dosa", "मसाला डोसा", "Aloo masala bhara! Speed + Haste.", "आलू मसाला भरा! स्पीड और हेस्ट।"),
    "biryani": ("Biryani", "बिरयानी", "Dum wali biryani, sabki baap! Strength + Regeneration + Speed + Absorption.", "दम वाली बिरयानी, सबकी बाप! स्ट्रेंथ, रीजनरेशन, स्पीड और एब्ज़ॉर्प्शन।"),
    "thali": ("Thali", "थाली", "Poora khana ek plate mein. Regeneration II, Resistance, Strength, Health Boost II.", "पूरा खाना एक प्लेट में। रीजनरेशन II, रेसिस्टेंस, स्ट्रेंथ, हेल्थ बूस्ट II।"),
    "chai": ("Masala Chai", "मसाला चाय", "Chai pi, kaam ho jaayega! Speed + Haste.", "चाय पी, काम हो जाएगा! स्पीड और हेस्ट।"),
    "lassi": ("Sweet Lassi", "मीठी लस्सी", "Garmi mein thandak. Absorption + Fire Resistance.", "गर्मी में ठंडक। एब्ज़ॉर्प्शन और फायर रेसिस्टेंस।"),
}

INGREDIENTS = {
    "atta": ("Atta (Wheat Flour)", "आटा"),
    "atta_dough": ("Atta Dough", "आटे की लोई"),
    "besan": ("Besan (Gram Flour)", "बेसन"),
    "chawal": ("Chawal (Rice)", "चावल"),
    "haldi": ("Haldi (Turmeric)", "हल्दी"),
    "lal_mirch": ("Lal Mirch (Red Chilli)", "लाल मिर्च"),
    "jeera": ("Jeera (Cumin)", "जीरा"),
    "elaichi": ("Elaichi (Cardamom)", "इलायची"),
    "garam_masala": ("Garam Masala", "गरम मसाला"),
    "ghee": ("Ghee", "घी"),
    "paneer": ("Paneer", "पनीर"),
    "dahi": ("Dahi (Curd)", "दही"),
    "chai_patti": ("Chai Patti (Tea Leaves)", "चायपत्ती"),
}

ALL_IDS = list(FOODS) + list(INGREDIENTS)

# ----------------------------------------------------------------- models
for item_id in ALL_IDS:
    write(os.path.join(ASSETS, "models/item", item_id + ".json"), {
        "parent": "minecraft:item/generated",
        "textures": {"layer0": "desifood:item/" + item_id},
    })

write(os.path.join(ASSETS, "models/item/tandoor.json"), {"parent": "desifood:block/tandoor"})
write(os.path.join(ASSETS, "models/block/tandoor.json"), {
    "parent": "minecraft:block/block",
    "textures": {
        "particle": "desifood:block/tandoor_side",
        "front": "desifood:block/tandoor_front",
        "side": "desifood:block/tandoor_side",
        "top": "desifood:block/tandoor_top",
    },
    "elements": [{
        "from": [0, 0, 0],
        "to": [16, 16, 16],
        "faces": {
            "down": {"texture": "#side", "cullface": "down"},
            "up": {"texture": "#top", "cullface": "up"},
            "north": {"texture": "#front", "cullface": "north"},
            "south": {"texture": "#side", "cullface": "south"},
            "west": {"texture": "#side", "cullface": "west"},
            "east": {"texture": "#side", "cullface": "east"},
        },
    }],
})
write(os.path.join(ASSETS, "blockstates/tandoor.json"), {
    "variants": {
        "facing=north": {"model": "desifood:block/tandoor"},
        "facing=east": {"model": "desifood:block/tandoor", "y": 90},
        "facing=south": {"model": "desifood:block/tandoor", "y": 180},
        "facing=west": {"model": "desifood:block/tandoor", "y": 270},
    }
})

# ------------------------------------------------------------------- lang
en = {"itemGroup.desifood.main": "Desi Food", "block.desifood.tandoor": "Tandoor"}
hi = {"itemGroup.desifood.main": "देसी खाना", "block.desifood.tandoor": "तंदूर"}
for item_id, (name_en, name_hi, tip_en, tip_hi) in FOODS.items():
    en["item.desifood." + item_id] = name_en
    en["item.desifood." + item_id + ".tooltip"] = tip_en
    hi["item.desifood." + item_id] = name_hi
    hi["item.desifood." + item_id + ".tooltip"] = tip_hi
for item_id, (name_en, name_hi) in INGREDIENTS.items():
    en["item.desifood." + item_id] = name_en
    hi["item.desifood." + item_id] = name_hi
write(os.path.join(ASSETS, "lang/en_us.json"), en)
write(os.path.join(ASSETS, "lang/hi_in.json"), hi)

# ---------------------------------------------------------------- recipes


def ing(name):
    return {"item": name if ":" in name else "desifood:" + name}


def res(name, count=1):
    r = {"item": name if ":" in name else "desifood:" + name}
    if count != 1:
        r["count"] = count
    return r


def shapeless(name, ingredients, result, count=1):
    write(os.path.join(DATA, "recipes", name + ".json"), {
        "type": "minecraft:crafting_shapeless",
        "category": "misc",
        "ingredients": [ing(i) for i in ingredients],
        "result": res(result, count),
    })


def cooking(name, kind, ingredient, result, xp, time):
    write(os.path.join(DATA, "recipes", name + ".json"), {
        "type": "minecraft:" + kind,
        "category": "food",
        "ingredient": ing(ingredient),
        "result": "desifood:" + result,
        "experience": xp,
        "cookingtime": time,
    })


M = "minecraft:"
# ingredients
shapeless("atta", [M + "wheat"] * 3, "atta", 2)
shapeless("besan", [M + "wheat", M + "wheat", M + "yellow_dye"], "besan", 3)
shapeless("chawal", [M + "wheat_seeds"] * 3, "chawal", 2)
shapeless("haldi", [M + "carrot", M + "yellow_dye"], "haldi", 2)
shapeless("lal_mirch", [M + "beetroot", M + "red_dye"], "lal_mirch", 2)
shapeless("jeera", [M + "wheat_seeds", M + "cocoa_beans"], "jeera", 2)
shapeless("elaichi", [M + "melon_seeds", M + "lime_dye"], "elaichi", 2)
shapeless("garam_masala", ["jeera", "lal_mirch", "haldi", "elaichi"], "garam_masala", 2)
shapeless("ghee", [M + "milk_bucket", M + "coal"], "ghee", 3)
shapeless("paneer", [M + "milk_bucket", M + "sweet_berries"], "paneer", 3)
shapeless("dahi", [M + "milk_bucket", M + "sugar"], "dahi", 3)
shapeless("chai_patti", [M + "fern", M + "cocoa_beans"], "chai_patti", 2)
shapeless("atta_dough", ["atta", "atta", M + "water_bucket"], "atta_dough", 4)

# sweets
shapeless("jalebi", ["besan", M + "sugar", "ghee"], "jalebi", 3)
shapeless("gulab_jamun", ["paneer", M + "sugar", "ghee"], "gulab_jamun", 3)
shapeless("laddu", ["besan", "ghee", M + "sugar", M + "sugar"], "laddu", 3)
shapeless("rasgulla", ["paneer", M + "sugar", M + "water_bucket"], "rasgulla", 3)
shapeless("kheer", ["chawal", M + "milk_bucket", M + "sugar", M + "bowl"], "kheer")
shapeless("kulfi", [M + "milk_bucket", M + "sugar", "elaichi", M + "snowball", M + "stick"], "kulfi", 2)

# breads
cooking("roti_from_smelting", "smelting", "atta_dough", "roti", 0.35, 200)
cooking("roti_from_smoking", "smoking", "atta_dough", "roti", 0.35, 100)
cooking("roti_from_campfire_cooking", "campfire_cooking", "atta_dough", "roti", 0.35, 600)
shapeless("naan", ["atta_dough", "dahi"], "naan")
shapeless("butter_naan", ["naan", "ghee"], "butter_naan")
shapeless("aloo_paratha", ["atta_dough", "atta_dough", M + "baked_potato", "ghee"], "aloo_paratha", 2)

# snacks
shapeless("samosa", ["atta_dough", M + "baked_potato", "garam_masala"], "samosa", 2)
shapeless("pani_puri", ["atta_dough", "jeera", "lal_mirch", M + "water_bucket"], "pani_puri", 4)
shapeless("dhokla", ["besan", "dahi", "haldi"], "dhokla", 2)
shapeless("vada_pav", [M + "bread", M + "baked_potato", "lal_mirch", "besan"], "vada_pav", 2)
shapeless("pav_bhaji", [M + "bread", M + "bread", M + "baked_potato", M + "beetroot", "ghee"], "pav_bhaji", 2)

# mains
shapeless("paneer_tikka", ["paneer", "paneer", "lal_mirch", M + "stick"], "paneer_tikka", 2)
shapeless("tandoori_chicken", [M + "cooked_chicken", "lal_mirch", "dahi", "garam_masala"], "tandoori_chicken")
shapeless("butter_chicken", [M + "cooked_chicken", "ghee", "garam_masala", "dahi", M + "bowl"], "butter_chicken")
shapeless("paneer_butter_masala", [M + "bowl", "paneer", "ghee", "garam_masala", "dahi"], "paneer_butter_masala")
shapeless("dal_tadka", [M + "bowl", M + "pumpkin_seeds", M + "pumpkin_seeds", "haldi", "jeera", "ghee"], "dal_tadka")
shapeless("rajma_chawal", [M + "bowl", "chawal", M + "beetroot", "garam_masala"], "rajma_chawal")
shapeless("chole_bhature", ["atta_dough", M + "pumpkin_seeds", M + "pumpkin_seeds", "garam_masala", "ghee"], "chole_bhature")

# south indian
shapeless("idli", ["chawal", "chawal", "dahi"], "idli", 3)
shapeless("dosa", ["chawal", "chawal", "dahi", "ghee"], "dosa", 2)
shapeless("masala_dosa", ["dosa", M + "baked_potato", "garam_masala"], "masala_dosa")

# feasts and drinks
shapeless("biryani", [M + "bowl", "chawal", "chawal", M + "cooked_chicken", "garam_masala"], "biryani")
shapeless("thali", ["roti", "dal_tadka", "rajma_chawal", "gulab_jamun"], "thali")
shapeless("chai", [M + "milk_bucket", "chai_patti", M + "sugar", "elaichi"] + [M + "glass_bottle"] * 3, "chai", 3)
shapeless("lassi", ["dahi", "dahi", M + "sugar", M + "glass_bottle", M + "glass_bottle"], "lassi", 2)

# tandoor block
write(os.path.join(DATA, "recipes/tandoor.json"), {
    "type": "minecraft:crafting_shaped",
    "category": "misc",
    "pattern": ["BBB", "B B", "BFB"],
    "key": {"B": {"item": "minecraft:brick"}, "F": {"item": "minecraft:campfire"}},
    "result": {"item": "desifood:tandoor"},
})

# ------------------------------------------------------- loot table + tags
write(os.path.join(DATA, "loot_tables/blocks/tandoor.json"), {
    "type": "minecraft:block",
    "pools": [{
        "rolls": 1.0,
        "bonus_rolls": 0.0,
        "entries": [{"type": "minecraft:item", "name": "desifood:tandoor"}],
        "conditions": [{"condition": "minecraft:survives_explosion"}],
    }],
})
write(os.path.join(RES, "data/minecraft/tags/blocks/mineable/pickaxe.json"), {"values": ["desifood:tandoor"]})
print("generated data for", len(ALL_IDS), "items")
