#!/usr/bin/env python3
"""Generates all original 16x16 pixel-art textures for the Desi Food mod."""
import math
import os
import random
import sys

from PIL import Image

ROOT = sys.argv[1]
ITEM_DIR = os.path.join(ROOT, "src/main/resources/assets/desifood/textures/item")
BLOCK_DIR = os.path.join(ROOT, "src/main/resources/assets/desifood/textures/block")
ICON_PATH = os.path.join(ROOT, "src/main/resources/assets/desifood/icon.png")
os.makedirs(ITEM_DIR, exist_ok=True)
os.makedirs(BLOCK_DIR, exist_ok=True)

random.seed(42)


def hx(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4)) + (255,)


def mix(c, target, f):
    return tuple(int(c[i] + (target[i] - c[i]) * f) for i in range(3)) + (255,)


def lighten(c, f=0.25):
    return mix(c, (255, 255, 255), f)


def darken(c, f=0.3):
    return mix(c, (0, 0, 0), f)


class Tex:
    def __init__(self):
        self.im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))

    def opaque(self, x, y):
        return 0 <= x < 16 and 0 <= y < 16 and self.im.getpixel((x, y))[3] > 0

    def px(self, x, y, c):
        x, y = int(x), int(y)
        if 0 <= x < 16 and 0 <= y < 16:
            self.im.putpixel((x, y), c if len(c) == 4 else c + (255,))

    def top(self, x, y, c):
        """Paint only where something already exists (toppings, speckles)."""
        if self.opaque(int(x), int(y)):
            self.px(x, y, c)

    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.px(x, y, c)

    def ell(self, cx, cy, rx, ry, c, shade=True, hl=0.3, sh=0.28):
        for y in range(16):
            for x in range(16):
                nx = (x + 0.5 - cx) / rx
                ny = (y + 0.5 - cy) / ry
                if nx * nx + ny * ny <= 1.0:
                    col = c
                    if shade:
                        v = (nx + ny) / 2
                        if v < -0.32:
                            col = lighten(c, hl)
                        elif v > 0.34:
                            col = darken(c, sh)
                    self.px(x, y, col)

    def inell(self, x, y, cx, cy, rx, ry):
        nx = (x + 0.5 - cx) / rx
        ny = (y + 0.5 - cy) / ry
        return nx * nx + ny * ny <= 1.0

    def poly(self, pts, c, shade_x=None):
        from PIL import ImageDraw
        mask = Image.new("L", (16, 16), 0)
        ImageDraw.Draw(mask).polygon(pts, fill=255)
        for y in range(16):
            for x in range(16):
                if mask.getpixel((x, y)):
                    col = c
                    if shade_x is not None:
                        if x + 0.5 < shade_x - 1:
                            col = lighten(c, 0.16)
                        elif x + 0.5 > shade_x + 1:
                            col = darken(c, 0.18)
                    self.px(x, y, col)

    def line(self, x0, y0, x1, y1, c):
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx + dy
        while True:
            self.px(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def outline(self, f=0.55):
        snap = self.im.copy()
        for y in range(16):
            for x in range(16):
                if snap.getpixel((x, y))[3] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < 16 and 0 <= ny < 16:
                            n = snap.getpixel((nx, ny))
                            if n[3] > 0:
                                self.im.putpixel((x, y), darken(n, f))
                                break

    def steam(self, pts):
        for (x, y) in pts:
            if 0 <= x < 16 and 0 <= y < 16 and self.im.getpixel((int(x), int(y)))[3] == 0:
                self.im.putpixel((int(x), int(y)), (255, 255, 255, 170))

    def save(self, path):
        self.im.save(path)


ITEMS = {}


def item(fn):
    ITEMS[fn.__name__] = fn
    return fn


# ----------------------------------------------------------------- helpers
def bowl(t, content, rim="#F2EFE6", body="#C45A2C", band="#F5D58A"):
    rimc, bodyc, bandc = hx(rim), hx(body), hx(band)
    for y in range(9, 15):
        half = 7.2 - (y - 9) * 0.75
        for x in range(16):
            dx = x + 0.5 - 8
            if abs(dx) <= half:
                c = bodyc
                if dx > half - 1.8:
                    c = darken(bodyc, 0.25)
                elif dx < -half + 1.6:
                    c = lighten(bodyc, 0.15)
                t.px(x, y, c)
    for x in range(16):
        if t.opaque(x, 11) and x % 2 == 0:
            t.px(x, 11, bandc)
    t.ell(8, 8.5, 7, 3, rimc, shade=False)
    t.ell(8, 8.5, 6, 2.2, hx(content), shade=False)


def sack(t, cloth, rope, mark):
    c, r, m = hx(cloth), hx(rope), hx(mark)
    t.poly([(3, 5), (12, 5), (14, 8), (14, 14), (2, 14), (2, 8)], c, shade_x=8)
    t.rect(5, 2, 10, 5, lighten(c, 0.1))
    t.rect(4, 5, 11, 5, r)
    t.px(3, 4, c)
    t.px(12, 4, c)
    for x in range(5, 11):
        t.px(x, 3, darken(c, 0.12) if x % 2 else lighten(c, 0.2))
    t.rect(6, 8, 9, 11, m)
    t.px(7, 7, m)
    t.px(8, 7, m)
    for x in (3, 13):
        for y in range(9, 14, 2):
            t.top(x, y, darken(c, 0.2))


def glass_cup(t, liquid, foam, handle=True, tall=False):
    glass = hx("#CFE6EE")
    glass_dark = hx("#8FB3C2")
    top_y = 3 if tall else 5
    for y in range(top_y, 14):
        half = 3.4 + (0.5 if tall and y < 8 else 0) + (0.2 if not tall and y < 8 else 0)
        for x in range(16):
            dx = x + 0.5 - 7.5
            if abs(dx) <= half:
                if abs(abs(dx) - half) < 1.0:
                    t.px(x, y, glass if dx < 0 else glass_dark)
                else:
                    t.px(x, y, hx(liquid) if y > top_y + 1 else hx(foam))
    if handle:
        for (x, y) in [(12, 7), (13, 7), (13, 8), (13, 9), (13, 10), (12, 11)]:
            t.px(x, y, glass_dark)


# ----------------------------------------------------------------- foods
@item
def samosa():
    t = Tex()
    base = hx("#E3A63A")
    for y in range(2, 14):
        half = (y - 1) * 0.5 + 0.6
        for x in range(16):
            dx = x + 0.5 - 8
            if abs(dx) <= half:
                c = base
                if dx < -1:
                    c = lighten(base, 0.18)
                elif dx > 1.5:
                    c = darken(base, 0.18)
                t.px(x, y, c)
    for x in range(1, 15):
        if t.opaque(x, 13):
            t.px(x, 13, darken(base, 0.4) if x % 2 == 0 else darken(base, 0.18))
    for y in range(4, 13):
        t.top(8, y, lighten(base, 0.35))
    for (x, y) in [(5, 10), (10, 9), (7, 7), (11, 11), (4, 12), (8, 11), (9, 5), (6, 12)]:
        t.top(x, y, darken(base, 0.28))
    for (x, y) in [(6, 9), (10, 11), (8, 6)]:
        t.top(x, y, hx("#F9D480"))
    t.outline(0.5)
    t.steam([(11, 1), (12, 0)])
    return t


@item
def jalebi():
    t = Tex()
    base = hx("#F08A14")
    cx, cy = 8.0, 8.0
    pitch = 3.0
    for y in range(16):
        for x in range(16):
            dx, dy = x + 0.5 - cx, y + 0.5 - cy
            r = math.hypot(dx, dy)
            th = math.atan2(dy, dx)
            best = 99
            for n in range(0, 4):
                rt = 1.2 + pitch * (th + 2 * math.pi * n) / (2 * math.pi) + 0.0
                if rt < 0.8 or rt > 7.2:
                    continue
                best = min(best, abs(r - rt))
            if best < 1.0:
                v = (dx + dy) / 14
                c = base
                if v < -0.2:
                    c = lighten(base, 0.3)
                elif v > 0.25:
                    c = darken(base, 0.25)
                t.px(x, y, c)
    for (x, y) in [(4, 5), (9, 3), (12, 8), (5, 11)]:
        t.top(x, y, hx("#FFE9A8"))
    t.outline(0.5)
    return t


def balls_in_bowl(ball, syrup, bowlc, band):
    t = Tex()
    bowl(t, syrup, rim="#F2EFE6", body=bowlc, band=band)
    for (cx, cy) in [(5.5, 6.0), (10.5, 6.0), (8, 4.6)]:
        t.ell(cx, cy, 2.9, 2.9, hx(ball))
    t.outline(0.55)
    return t


@item
def gulab_jamun():
    t = balls_in_bowl("#6B2D14", "#E9A23B", "#B24A24", "#F5D58A")
    for (x, y) in [(4, 5), (9, 5), (7, 3)]:
        t.top(x, y, hx("#A8502A"))
    for (x, y) in [(5, 8), (8, 8), (11, 8)]:
        t.top(x, y, hx("#FFD36B"))
    return t


@item
def rasgulla():
    t = balls_in_bowl("#F7F3E8", "#F1DC8C", "#4B86B8", "#EAF2F8")
    for (x, y) in [(4, 5), (9, 5), (7, 3)]:
        t.top(x, y, hx("#FFFFFF"))
    for (x, y) in [(6, 7), (11, 7)]:
        t.top(x, y, hx("#C9C4B2"))
    return t


@item
def laddu():
    t = Tex()
    base = hx("#F2A32C")
    t.ell(8, 8.5, 6.6, 6.2, base)
    random.seed(3)
    for _ in range(26):
        x, y = random.randint(2, 13), random.randint(3, 14)
        t.top(x, y, darken(base, 0.22) if random.random() < 0.6 else lighten(base, 0.3))
    for (x, y) in [(6, 4), (9, 3), (11, 6), (4, 7), (7, 5)]:
        t.top(x, y, hx("#6FAE3C"))
    t.top(8, 2, hx("#E8C060"))
    t.outline(0.5)
    return t


@item
def kheer():
    t = Tex()
    bowl(t, "#F7EFD8", rim="#F4F1EA", body="#2F6FA8", band="#F4F1EA")
    for (x, y) in [(6, 8), (10, 9), (8, 7), (5, 9)]:
        t.top(x, y, hx("#5A3A1E"))
    for (x, y) in [(7, 8), (9, 8), (11, 8), (6, 10)]:
        t.top(x, y, hx("#8DBB4B"))
    for (x, y) in [(8, 8), (9, 7), (7, 9)]:
        t.top(x, y, hx("#F28C1E"))
    t.outline(0.5)
    t.steam([(6, 4), (6, 3), (10, 5), (10, 4)])
    return t


@item
def kulfi():
    t = Tex()
    base = hx("#F5E6B8")
    for y in range(1, 12):
        half = 3.4 if y > 2 else (2.0 if y == 1 else 3.0)
        for x in range(16):
            dx = x + 0.5 - 8
            if abs(dx) <= half:
                c = base
                if dx < -1.2:
                    c = lighten(base, 0.35)
                elif dx > 1.2:
                    c = darken(base, 0.14)
                t.px(x, y, c)
    for (x, y) in [(7, 3), (9, 5), (6, 7), (9, 9), (8, 6)]:
        t.top(x, y, hx("#7FB347"))
    for (x, y) in [(8, 3), (7, 5), (9, 7), (6, 9), (8, 10)]:
        t.top(x, y, hx("#F08A1E"))
    t.rect(7, 12, 8, 15, hx("#B07A3E"))
    t.px(8, 12, hx("#8A5A2A"))
    t.px(8, 13, hx("#8A5A2A"))
    t.outline(0.5)
    return t


@item
def roti():
    t = Tex()
    base = hx("#E2B06A")
    t.ell(8, 8, 7.2, 6.4, base)
    t.ell(8, 8, 5.2, 4.4, lighten(base, 0.14), shade=False)
    for (x, y) in [(5, 6), (10, 5), (8, 9), (11, 10), (4, 10), (7, 4), (12, 8)]:
        t.top(x, y, hx("#8B5A2B"))
        t.top(x + 1, y, darken(base, 0.25))
    t.outline(0.5)
    return t


@item
def naan():
    t = Tex()
    base = hx("#EBCB8B")
    t.poly([(8, 1), (12, 5), (13, 9), (11, 13), (8, 15), (5, 13), (3, 9), (4, 5)], base, shade_x=8)
    for (x, y) in [(7, 5), (10, 7), (6, 9), (9, 11), (8, 8), (11, 11), (5, 6)]:
        t.top(x, y, hx("#9A5E2A"))
        t.top(x, y + 1, darken(base, 0.2))
    for (x, y) in [(7, 7), (9, 9), (6, 11), (10, 5)]:
        t.top(x, y, hx("#4F9A3A"))
    t.top(8, 3, lighten(base, 0.3))
    t.outline(0.5)
    return t


@item
def butter_naan():
    t = naan()
    t.rect(6, 6, 9, 9, hx("#FFE066"))
    t.rect(6, 6, 9, 6, hx("#FFF3A8"))
    t.rect(9, 6, 9, 9, hx("#E8C23A"))
    for (x, y) in [(7, 10), (8, 11), (6, 10)]:
        t.top(x, y, hx("#F6D75A"))
    t.outline(0.5)
    return t


@item
def aloo_paratha():
    t = Tex()
    base = hx("#D99B3F")
    t.ell(8, 8, 7, 6.6, base)
    for r in (2.0, 4.0, 5.6):
        for a in range(0, 360, 6):
            x = 8 + math.cos(math.radians(a)) * r
            y = 8 + math.sin(math.radians(a)) * r * 0.93
            t.top(int(x), int(y), darken(base, 0.12))
    for (x, y) in [(5, 5), (10, 6), (9, 10), (4, 9), (11, 11)]:
        t.top(x, y, hx("#7A4A1A"))
    for y in range(10, 15):
        for x in range(9, 16):
            if t.inell(x, y, 12.5, 12.5, 3.1, 2.8):
                t.px(x, y, (0, 0, 0, 0))
    for (x, y) in [(10, 12), (11, 11), (12, 10), (11, 12), (12, 11), (10, 13), (13, 11)]:
        t.top(x, y, hx("#F3E2A0"))
    t.rect(4, 7, 5, 8, hx("#FFE066"))
    t.px(4, 7, hx("#FFF3A8"))
    t.outline(0.5)
    return t


@item
def paneer_tikka():
    t = Tex()
    t.line(1, 14, 14, 1, hx("#9C6B3A"))
    t.line(2, 14, 14, 2, hx("#7A4F26"))
    cubes = [((3, 9), "#F5EFD8", True), ((6, 6), "#4C9A3C", False), ((9, 3), "#F5EFD8", True)]
    for (cx, cy), col, paneer in cubes:
        base = hx(col)
        t.rect(cx, cy, cx + 4, cy + 4, base)
        t.rect(cx, cy, cx + 4, cy, lighten(base, 0.3))
        t.rect(cx + 4, cy, cx + 4, cy + 4, darken(base, 0.2))
        t.rect(cx, cy + 4, cx + 4, cy + 4, darken(base, 0.25))
        if paneer:
            for (dx, dy) in [(1, 1), (2, 2), (3, 1), (1, 3)]:
                t.px(cx + dx, cy + dy, hx("#E0562A"))
            t.px(cx + 2, cy + 3, hx("#8A2A12"))
    t.px(13, 2, hx("#E0562A"))
    t.outline(0.5)
    return t


@item
def tandoori_chicken():
    t = Tex()
    base = hx("#D6462A")
    t.line(8, 9, 13, 14, hx("#F4EFE0"))
    t.line(9, 9, 14, 14, hx("#D9D2BF"))
    t.rect(12, 13, 14, 15, hx("#F4EFE0"))
    t.rect(13, 12, 15, 14, hx("#F4EFE0"))
    t.px(14, 15, hx("#D9D2BF"))
    t.ell(6.5, 6.5, 5.6, 5.0, base)
    for (x, y) in [(4, 4), (7, 3), (9, 6), (6, 9), (3, 7), (8, 8)]:
        t.top(x, y, hx("#7A2A12"))
    for (x, y) in [(5, 5), (7, 6), (4, 8), (9, 4)]:
        t.top(x, y, hx("#F5A03A"))
    t.top(3, 4, lighten(base, 0.4))
    t.top(4, 3, lighten(base, 0.4))
    t.outline(0.5)
    t.steam([(5, 1), (5, 0), (9, 1)])
    return t


@item
def butter_chicken():
    t = Tex()
    bowl(t, "#D4531C", rim="#B8B4AC", body="#7C5230", band="#D9A66B")
    for (x, y) in [(5, 9), (10, 7), (8, 9)]:
        t.top(x, y, hx("#B5651D"))
        t.top(x + 1, y, hx("#C98036"))
    for (x, y) in [(6, 8), (7, 7), (8, 7), (9, 8), (10, 9)]:
        t.top(x, y, hx("#FFF1D6"))
    for (x, y) in [(4, 8), (11, 8), (7, 10)]:
        t.top(x, y, hx("#3E9A3A"))
    t.outline(0.5)
    t.steam([(6, 4), (6, 3), (10, 5), (10, 4)])
    return t


@item
def paneer_butter_masala():
    t = Tex()
    bowl(t, "#E47B2A", rim="#F2EFE6", body="#8E2F26", band="#F5D58A")
    for (x, y) in [(5, 7), (9, 8), (7, 9), (11, 9)]:
        t.rect(x, y, x + 1, y + 1, hx("#F8F1DA"))
        t.top(x + 1, y + 1, hx("#D9CFA8"))
    for (x, y) in [(6, 8), (8, 7), (10, 7), (7, 8)]:
        t.top(x, y, hx("#FFF6E5"))
    for (x, y) in [(4, 8), (11, 7), (8, 10)]:
        t.top(x, y, hx("#3E9A3A"))
    t.outline(0.5)
    t.steam([(5, 4), (5, 3), (9, 5), (9, 4)])
    return t


@item
def dal_tadka():
    t = Tex()
    bowl(t, "#E2B23A", rim="#C9CFD6", body="#8E96A2", band="#C9CFD6")
    for (x, y) in [(5, 8), (10, 7), (7, 9), (11, 9)]:
        t.top(x, y, hx("#B8231B"))
        t.top(x + 1, y, hx("#D84A2A"))
    for (x, y) in [(6, 7), (9, 9), (8, 8), (4, 9), (11, 8)]:
        t.top(x, y, hx("#8A6030"))
    for (x, y) in [(8, 7), (9, 10), (6, 10)]:
        t.top(x, y, hx("#3E9A3A"))
    t.outline(0.5)
    t.steam([(6, 4), (6, 3), (10, 5), (10, 4)])
    return t


@item
def rajma_chawal():
    t = Tex()
    bowl(t, "#F4F1E8", rim="#E8E4DA", body="#B8574A", band="#F4D6A0")
    for y in range(5, 12):
        for x in range(8, 14):
            if t.inell(x, y, 8, 8.5, 6, 2.2):
                t.px(x, y, hx("#7A2619"))
    for (x, y) in [(9, 7), (11, 8), (10, 9), (12, 9), (9, 10)]:
        t.top(x, y, hx("#A8402A"))
    for (x, y) in [(3, 8), (5, 9), (6, 7), (4, 10), (6, 10)]:
        t.top(x, y, hx("#D5D0C2"))
    t.top(7, 8, hx("#3E9A3A"))
    t.outline(0.5)
    t.steam([(5, 4), (5, 3), (10, 5), (10, 4)])
    return t


@item
def chole_bhature():
    t = Tex()
    t.ell(8, 4.8, 7, 4.2, hx("#E8B04A"))
    for (x, y) in [(4, 3), (7, 5), (10, 3), (12, 5), (6, 2), (9, 6)]:
        t.top(x, y, hx("#9A5E2A"))
    t.top(5, 2, hx("#F8D88A"))
    t.top(6, 2, hx("#F8D88A"))
    t.ell(8, 11.5, 6.8, 3.4, hx("#C98A3A"))
    for (x, y) in [(4, 10), (6, 12), (8, 10), (10, 12), (11, 10), (7, 13), (5, 11), (9, 11)]:
        t.top(x, y, hx("#E6B25C"))
        t.top(x, y + 1, hx("#8A5A22"))
    for (x, y) in [(9, 9), (10, 9), (11, 10)]:
        t.top(x, y, hx("#C94A7A"))
    t.top(6, 11, hx("#3E9A3A"))
    t.outline(0.5)
    return t


@item
def pav_bhaji():
    t = Tex()
    t.ell(5, 5, 3.8, 3.0, hx("#E6B96B"))
    t.ell(10.5, 4.5, 3.8, 3.0, hx("#EAC27A"))
    for (x, y) in [(4, 4), (9, 3), (11, 5)]:
        t.top(x, y, hx("#B8802E"))
    t.ell(8, 11, 7.4, 3.8, hx("#C73A1A"))
    for (x, y) in [(4, 10), (6, 12), (10, 10), (11, 12), (8, 9)]:
        t.top(x, y, hx("#E5601E"))
    for (x, y) in [(7, 11), (9, 12), (12, 11)]:
        t.top(x, y, hx("#8A1E10"))
    t.rect(7, 9, 9, 10, hx("#FFE066"))
    t.px(7, 9, hx("#FFF3A8"))
    for (x, y) in [(5, 11), (11, 10), (6, 13)]:
        t.top(x, y, hx("#3E9A3A"))
    t.outline(0.5)
    return t


@item
def vada_pav():
    t = Tex()
    bun = hx("#E6B96B")
    t.ell(8, 12, 7, 3, darken(bun, 0.12))
    t.ell(8, 9, 4.2, 4.0, hx("#E0A52E"))
    for (x, y) in [(6, 8), (9, 7), (8, 10), (10, 10), (7, 6)]:
        t.top(x, y, hx("#A8741A"))
    t.ell(8, 4, 7, 3.2, bun)
    for (x, y) in [(5, 3), (8, 2), (11, 3), (7, 4)]:
        t.top(x, y, lighten(bun, 0.5))
    t.rect(3, 7, 12, 7, hx("#2E9E3A"))
    t.rect(4, 8, 6, 8, hx("#C8321E"))
    t.rect(11, 6, 14, 7, hx("#2E9E3A"))
    t.outline(0.5)
    return t


@item
def pani_puri():
    t = Tex()
    base = hx("#E0A244")
    t.ell(8, 9, 6.0, 5.6, base)
    t.ell(8, 5.6, 3.4, 1.6, hx("#3A2412"), shade=False)
    t.ell(8, 5.9, 2.6, 1.0, hx("#52B36F"), shade=False)
    for (x, y) in [(5, 9), (10, 8), (8, 11), (11, 11), (6, 12)]:
        t.top(x, y, darken(base, 0.22))
    t.top(5, 7, lighten(base, 0.4))
    t.outline(0.5)
    for (x, y) in [(13, 4), (13, 5), (14, 6)]:
        t.px(x, y, hx("#52B36F"))
    t.px(2, 4, hx("#52B36F"))
    return t


@item
def dhokla():
    t = Tex()
    base = hx("#F3D13B")
    for (x0, y0) in [(1, 8), (7, 8), (4, 3)]:
        t.rect(x0, y0, x0 + 6, y0 + 4, base)
        t.rect(x0, y0, x0 + 6, y0, lighten(base, 0.4))
        t.rect(x0 + 6, y0, x0 + 6, y0 + 4, darken(base, 0.2))
        t.rect(x0, y0 + 4, x0 + 6, y0 + 4, darken(base, 0.25))
        for (dx, dy) in [(1, 2), (3, 1), (4, 3), (2, 3)]:
            t.px(x0 + dx, y0 + dy, darken(base, 0.18))
    for (x, y) in [(3, 9), (9, 9), (6, 4), (11, 11), (5, 11)]:
        t.top(x, y, hx("#2A1A10"))
    t.rect(2, 7, 4, 7, hx("#3E9A3A"))
    t.rect(9, 7, 11, 7, hx("#3E9A3A"))
    t.outline(0.5)
    return t


@item
def idli():
    t = Tex()
    base = hx("#F6F3EA")
    t.ell(8, 10.5, 6.6, 3.6, base)
    t.ell(8, 6.5, 5.6, 3.4, lighten(base, 0.1))
    for x in range(3, 14):
        t.top(x, 8, darken(base, 0.14))
    for (x, y) in [(6, 5), (9, 6), (7, 10), (11, 11)]:
        t.top(x, y, darken(base, 0.1))
    t.ell(13, 13, 2.4, 1.8, hx("#4FA55F"))
    t.top(12, 12, hx("#E8F5EA"))
    t.outline(0.5)
    t.steam([(6, 2), (6, 1), (10, 2), (10, 1)])
    return t


@item
def dosa():
    t = Tex()
    base = hx("#DDA143")
    t.poly([(1, 11), (3, 6), (8, 3), (13, 6), (15, 11), (8, 13)], base, shade_x=8)
    for r in range(3):
        for x in range(2, 15):
            t.top(x, 6 + r * 2 + (1 if x % 4 == 0 else 0), darken(base, 0.14))
    for (x, y) in [(5, 8), (10, 7), (8, 11), (12, 9), (3, 10)]:
        t.top(x, y, hx("#9A5E1E"))
    t.line(8, 4, 8, 12, lighten(base, 0.35))
    t.ell(3.5, 14, 2.2, 1.4, hx("#F4F1E8"))
    t.top(3, 14, hx("#4FA55F"))
    t.ell(12.5, 14, 2.2, 1.4, hx("#C8321E"))
    t.outline(0.5)
    return t


@item
def masala_dosa():
    t = Tex()
    base = hx("#D79A3C")
    t.poly([(1, 13), (4, 8), (11, 1), (15, 5), (8, 12), (3, 15)], base, shade_x=8)
    for i in range(4):
        t.line(3 + i, 13 - i, 12 + i // 2, 2 + i + 1, darken(base, 0.18))
    t.ell(13, 3.2, 2.8, 2.8, hx("#EAC435"))
    for (x, y) in [(12, 2), (14, 3), (13, 4), (11, 3)]:
        t.top(x, y, hx("#C8321E"))
    t.top(13, 2, hx("#3E9A3A"))
    for (x, y) in [(6, 10), (8, 7), (10, 5), (4, 12)]:
        t.top(x, y, hx("#8A5A1E"))
    t.ell(12, 13, 2.8, 2.0, hx("#F4F1E8"))
    t.top(11, 13, hx("#4FA55F"))
    t.top(12, 12, hx("#4FA55F"))
    t.outline(0.5)
    return t


@item
def biryani():
    t = Tex()
    bowl(t, "#E8B83A", rim="#D4A24A", body="#8E2F26", band="#F5D58A")
    t.ell(8, 6.4, 5.8, 3.8, hx("#EBC04C"))
    random.seed(11)
    for _ in range(30):
        x, y = random.randint(3, 12), random.randint(3, 9)
        col = random.choice(["#FFF4C8", "#F08A1E", "#FFF4C8", "#D79A2A"])
        t.top(x, y, hx(col))
    for (x, y) in [(5, 5), (9, 4), (7, 7), (11, 6)]:
        t.top(x, y, hx("#6B3A18"))
    for (x, y) in [(6, 4), (10, 7), (4, 7)]:
        t.top(x, y, hx("#3E9A3A"))
    t.rect(8, 5, 10, 6, hx("#A8541E"))
    t.top(8, 5, hx("#C98036"))
    t.outline(0.5)
    t.steam([(5, 2), (5, 1), (6, 0), (10, 2), (10, 1), (9, 0)])
    return t


@item
def thali():
    t = Tex()
    t.ell(8, 8, 7.7, 7.7, hx("#B9C0CA"))
    t.ell(8, 8, 6.5, 6.5, hx("#D7DCE3"), shade=False)
    for (cx, cy, col) in [(4.6, 5.6, "#E2B23A"), (8, 3.9, "#D4531C"), (11.4, 5.6, "#F8F5EC")]:
        t.ell(cx, cy, 2.2, 2.2, hx("#9AA3AE"), shade=False)
        t.ell(cx, cy, 1.6, 1.6, hx(col), shade=False)
    t.ell(5.8, 10.8, 3.2, 3.0, hx("#E2B06A"))
    t.top(5, 10, hx("#8B5A2B"))
    t.top(7, 12, hx("#8B5A2B"))
    t.ell(11, 10.8, 2.7, 2.5, hx("#FBF8EE"))
    t.top(10, 10, hx("#D5D0C2"))
    t.top(12, 11, hx("#D5D0C2"))
    t.ell(9, 7.6, 1.1, 1.1, hx("#6B2D14"))
    t.top(11, 5, hx("#3E9A3A"))
    t.outline(0.5)
    return t


@item
def chai():
    t = Tex()
    glass_cup(t, "#A0612A", "#E3B98A")
    t.ell(7.5, 14, 6.0, 1.6, hx("#F2EFE6"), shade=False)
    for x in range(5, 11):
        t.top(x, 8, hx("#7A4418"))
    t.px(6, 6, hx("#F5DFC0"))
    t.outline(0.5)
    t.steam([(6, 3), (7, 2), (6, 1), (9, 3), (10, 2), (9, 1)])
    return t


@item
def lassi():
    t = Tex()
    glass_cup(t, "#F6EBDD", "#FFFFFF", handle=False, tall=True)
    for y in range(9, 14):
        for x in range(5, 11):
            t.top(x, y, hx("#F4C6D0") if y > 10 else hx("#F9DCDF"))
    t.line(11, 1, 9, 6, hx("#D63A3A"))
    t.line(12, 1, 10, 6, hx("#F4F1E8"))
    for (x, y) in [(6, 4), (8, 4), (9, 5), (7, 5)]:
        t.top(x, y, hx("#7FB347"))
    t.top(6, 5, hx("#E8527A"))
    t.top(9, 4, hx("#E8527A"))
    t.outline(0.5)
    return t


# ----------------------------------------------------------- ingredients
@item
def atta():
    t = Tex()
    sack(t, "#E8D8B0", "#8A5A2A", "#C9A24A")
    for (x, y) in [(5, 13), (9, 12), (11, 13)]:
        t.top(x, y, hx("#FFFFFF"))
    t.outline(0.5)
    return t


@item
def besan():
    t = Tex()
    sack(t, "#EBC93E", "#7A4F26", "#B8861E")
    for (x, y) in [(5, 13), (9, 12), (11, 13)]:
        t.top(x, y, hx("#FFF3A8"))
    t.outline(0.5)
    return t


@item
def atta_dough():
    t = Tex()
    base = hx("#EFE0C0")
    t.ell(8, 9, 6.4, 5.4, base)
    for (x, y) in [(5, 7), (8, 6), (10, 9), (6, 11), (9, 12), (4, 10), (11, 7)]:
        t.top(x, y, darken(base, 0.18))
        t.top(x, y - 1, lighten(base, 0.4))
    for (x, y) in [(3, 5), (6, 3), (12, 10), (10, 13), (13, 6)]:
        t.px(x, y, hx("#FFFFFF"))
    t.outline(0.5)
    return t


@item
def chawal():
    t = Tex()
    white = hx("#F7F5EC")
    for y in range(3, 14):
        half = (y - 2) * 0.62
        for x in range(16):
            dx = x + 0.5 - 8
            if abs(dx) <= half:
                c = white
                if dx < -1.5:
                    c = lighten(white, 0.0)
                elif dx > 1.5:
                    c = darken(white, 0.1)
                t.px(x, y, c)
    random.seed(5)
    for _ in range(26):
        x, y = random.randint(2, 13), random.randint(4, 13)
        t.top(x, y, hx("#D8D3C0"))
        t.top(x + 1, y, hx("#FFFFFF"))
    t.outline(0.45)
    return t


@item
def haldi():
    t = Tex()
    base = hx("#F0A818")
    for (x0, y0, x1, y1) in [(2, 12, 11, 3), (5, 14, 14, 6)]:
        for off in (-1, 0, 1):
            t.line(x0 + off, y0, x1 + off, y1, base)
            t.line(x0, y0 + off, x1, y1 + off, base)
    for i in range(0, 9, 2):
        x, y = 3 + i, 11 - i
        t.top(x, y, darken(base, 0.3))
        t.top(x + 1, y + 1, darken(base, 0.3))
        x, y = 6 + i, 13 - i
        t.top(x, y, darken(base, 0.3))
    for (x, y) in [(4, 9), (8, 6), (9, 10), (12, 8)]:
        t.top(x, y, hx("#FFD25A"))
    t.outline(0.5)
    return t


@item
def lal_mirch():
    t = Tex()
    red = hx("#D62820")
    for (pts, sx) in [([(3, 3), (5, 8), (8, 12), (13, 14)], 0), ([(8, 3), (10, 7), (12, 10), (14, 12)], 1)]:
        for i in range(len(pts) - 1):
            (x0, y0), (x1, y1) = pts[i], pts[i + 1]
            for off in (0, 1):
                t.line(x0 + off, y0, x1 + off, y1, red)
                t.line(x0, y0 + off, x1, y1 + off, red)
        sx0, sy0 = pts[0]
        t.rect(sx0 - 1, sy0 - 2, sx0 + 2, sy0, hx("#3F8F2F"))
        t.px(sx0, sy0 - 3, hx("#2F6F22"))
    for (x, y) in [(4, 5), (5, 6), (9, 5), (10, 7)]:
        t.top(x, y, hx("#FF7A66"))
    t.outline(0.5)
    return t


@item
def jeera():
    t = Tex()
    t.ell(8, 11, 6.6, 3.6, hx("#5A3A22"))
    t.ell(8, 8, 4.4, 3.2, hx("#6B452A"))
    seed = hx("#A87A3A")
    seed2 = hx("#C89A52")
    random.seed(9)
    for _ in range(30):
        x, y = random.randint(2, 13), random.randint(5, 13)
        if t.opaque(x, y):
            t.px(x, y, seed)
            t.top(x + 1, y - 1, seed2)
    t.outline(0.5)
    return t


@item
def elaichi():
    t = Tex()
    base = hx("#86B84C")
    for (cx, cy, rx, ry) in [(5, 6, 2.4, 3.8), (10.5, 5.5, 2.4, 3.8), (8, 11, 3.8, 2.4)]:
        t.ell(cx, cy, rx, ry, base)
    for y in range(3, 10):
        t.top(5, y, darken(base, 0.22))
        t.top(10, y, darken(base, 0.22))
    for x in range(5, 12):
        t.top(x, 11, darken(base, 0.22))
    t.px(8, 9, hx("#2A1A10"))
    t.px(9, 9, hx("#2A1A10"))
    t.px(7, 9, hx("#2A1A10"))
    t.outline(0.5)
    return t


@item
def garam_masala():
    t = Tex()
    t.ell(8, 11.5, 7, 3.4, hx("#8E5A2B"))
    t.ell(8, 9.5, 5.6, 3.0, hx("#8B3E1A"))
    random.seed(21)
    for _ in range(22):
        x, y = random.randint(3, 12), random.randint(7, 12)
        t.top(x, y, random.choice([hx("#6B2A10"), hx("#B8581E"), hx("#A8431A")]))
    t.line(3, 6, 12, 3, hx("#9A5A2A"))
    t.line(3, 7, 12, 4, hx("#B87A3E"))
    t.px(2, 6, hx("#6B3A18"))
    star = [(11, 9), (10, 10), (12, 10), (11, 11), (11, 10)]
    for (x, y) in star:
        t.px(x, y, hx("#4A2410"))
    t.px(11, 10, hx("#8A5A2A"))
    t.outline(0.5)
    return t


@item
def ghee():
    t = Tex()
    glass = hx("#D6E8EE")
    t.rect(4, 4, 11, 14, glass)
    t.rect(5, 6, 10, 13, hx("#F2C230"))
    t.rect(5, 6, 10, 7, hx("#FFE27A"))
    t.rect(10, 6, 10, 13, hx("#D9A41C"))
    t.rect(3, 2, 12, 4, hx("#C0392B"))
    t.rect(3, 2, 12, 2, hx("#E5604F"))
    t.rect(6, 9, 9, 11, hx("#FBF6E4"))
    t.px(7, 10, hx("#C0392B"))
    t.px(8, 10, hx("#C0392B"))
    t.px(5, 5, hx("#FFFFFF"))
    t.outline(0.5)
    return t


@item
def paneer():
    t = Tex()
    top, left, right = hx("#FBF7E8"), hx("#EBE4CC"), hx("#D5CCAE")
    t.poly([(8, 2), (14, 5), (8, 8), (2, 5)], top)
    t.poly([(2, 5), (8, 8), (8, 14), (2, 11)], left)
    t.poly([(8, 8), (14, 5), (14, 11), (8, 14)], right)
    for (x, y) in [(6, 4), (9, 5), (4, 9), (6, 11), (11, 8), (10, 11), (12, 7)]:
        t.top(x, y, darken(t.im.getpixel((x, y)), 0.14))
    t.line(8, 8, 8, 14, darken(left, 0.15))
    t.outline(0.5)
    return t


@item
def dahi():
    t = Tex()
    clay = hx("#B5532A")
    for y in range(7, 15):
        half = 5.5 + 1.8 * math.sin((y - 7) / 7 * math.pi * 0.8)
        if y > 12:
            half -= (y - 12) * 1.0
        for x in range(16):
            dx = x + 0.5 - 8
            if abs(dx) <= half:
                c = clay
                if dx > half - 2:
                    c = darken(clay, 0.28)
                elif dx < -half + 1.8:
                    c = lighten(clay, 0.18)
                t.px(x, y, c)
    for x in range(16):
        t.top(x, 10, hx("#7E3516") if x % 2 == 0 else hx("#E8A070"))
    t.ell(8, 6.8, 5.8, 2.4, hx("#C86A3A"), shade=False)
    t.ell(8, 6.8, 4.8, 1.7, hx("#FBF8F0"), shade=False)
    t.top(7, 6, hx("#E4DFD2"))
    t.top(8, 7, hx("#E4DFD2"))
    t.top(9, 6, hx("#E4DFD2"))
    t.outline(0.5)
    return t


@item
def chai_patti():
    t = Tex()
    t.ell(8, 11, 6.8, 3.6, hx("#3E2A1A"))
    t.ell(8, 8.5, 4.6, 3.2, hx("#4A3320"))
    random.seed(33)
    for _ in range(22):
        x, y = random.randint(2, 13), random.randint(6, 13)
        t.top(x, y, random.choice([hx("#5E4228"), hx("#2A1C10"), hx("#6B7A36")]))
    for (cx, cy, d) in [(5, 4, -1), (11, 4, 1)]:
        t.line(cx, cy + 2, cx + d * 2, cy - 1, hx("#4FA03C"))
        t.line(cx + 1, cy + 2, cx + d * 2 + 1, cy, hx("#6FBF4A"))
        t.px(cx + d * 2, cy - 2, hx("#6FBF4A"))
    t.outline(0.5)
    return t


# ---------------------------------------------------------------- blocks
def clay_noise(seed, base="#B8602F"):
    rnd = random.Random(seed)
    b = hx(base)
    im = Image.new("RGBA", (16, 16), b)
    for y in range(16):
        for x in range(16):
            r = rnd.random()
            c = b
            if r < 0.18:
                c = darken(b, 0.12)
            elif r > 0.84:
                c = lighten(b, 0.12)
            if x < 2:
                c = lighten(c, 0.06)
            if x > 13:
                c = darken(c, 0.14)
            im.putpixel((x, y), c)
    return im


def tandoor_side():
    im = clay_noise(1)
    for y, col in [(2, "#7E3D1B"), (3, "#D98A4E"), (12, "#D98A4E"), (13, "#7E3D1B")]:
        for x in range(16):
            im.putpixel((x, y), hx(col))
    for x in range(0, 16, 4):
        for y in (7, 8):
            im.putpixel((x, y), hx("#E8A870"))
            im.putpixel((x + 1, y), hx("#7E3D1B"))
    return im


def tandoor_top():
    im = clay_noise(2, "#A8542A")
    cx = cy = 7.5
    for y in range(16):
        for x in range(16):
            r = math.hypot(x - cx, y - cy)
            if r <= 6.4:
                im.putpixel((x, y), hx("#D98A4E") if r > 5.2 else hx("#7E3D1B"))
            if r <= 5.2:
                im.putpixel((x, y), hx("#1B0F0A"))
            if r <= 3.6:
                im.putpixel((x, y), hx("#7A2410"))
            if r <= 2.6:
                im.putpixel((x, y), hx("#E8501A"))
            if r <= 1.4:
                im.putpixel((x, y), hx("#FFB347"))
    for (x, y) in [(5, 6), (9, 9), (7, 10), (10, 6)]:
        im.putpixel((x, y), hx("#FF7A1A"))
    return im


def tandoor_front():
    im = tandoor_side()
    for y in range(6, 14):
        for x in range(4, 12):
            im.putpixel((x, y), hx("#3A1C0C"))
    for y in range(7, 14):
        for x in range(5, 11):
            if y == 7 and (x < 6 or x > 9):
                continue
            im.putpixel((x, y), hx("#120804"))
    for y in range(10, 14):
        for x in range(5, 11):
            im.putpixel((x, y), hx("#7A2410"))
    for y in range(11, 14):
        for x in range(6, 10):
            im.putpixel((x, y), hx("#E8501A"))
    for x in range(7, 9):
        im.putpixel((x, 12), hx("#FFB347"))
        im.putpixel((x, 13), hx("#FFB347"))
    for (x, y) in [(6, 10), (9, 10), (10, 12)]:
        im.putpixel((x, y), hx("#FF7A1A"))
    return im


def main():
    for name, fn in ITEMS.items():
        fn().save(os.path.join(ITEM_DIR, name + ".png"))
    tandoor_side().save(os.path.join(BLOCK_DIR, "tandoor_side.png"))
    tandoor_top().save(os.path.join(BLOCK_DIR, "tandoor_top.png"))
    tandoor_front().save(os.path.join(BLOCK_DIR, "tandoor_front.png"))

    # mod icon: tricolour band with a thali
    icon = Image.new("RGBA", (128, 128))
    bands = ["#FF9933", "#FFFFFF", "#138808"]
    for i, c in enumerate(bands):
        for y in range(i * 43, min(128, (i + 1) * 43 + 1)):
            for x in range(128):
                icon.putpixel((x, y), hx(c))
    thali_img = ITEMS["thali"]().im.resize((96, 96), Image.NEAREST)
    icon.alpha_composite(thali_img, (16, 16))
    icon.save(ICON_PATH)

    # contact sheet for visual QA
    names = list(ITEMS.keys())
    cols = 7
    rows = math.ceil(len(names) / cols)
    scale = 8
    sheet = Image.new("RGBA", (cols * 16 * scale + (cols + 1) * 8, rows * 16 * scale + (rows + 1) * 8), (70, 70, 80, 255))
    for i, n in enumerate(names):
        im = Image.open(os.path.join(ITEM_DIR, n + ".png")).resize((16 * scale, 16 * scale), Image.NEAREST)
        x = 8 + (i % cols) * (16 * scale + 8)
        y = 8 + (i // cols) * (16 * scale + 8)
        sheet.alpha_composite(im, (x, y))
    sheet.save(os.path.join(os.path.dirname(os.path.abspath(__file__)), "preview_items.png"))

    bsheet = Image.new("RGBA", (3 * 16 * scale + 32, 16 * scale + 16), (70, 70, 80, 255))
    for i, n in enumerate(["tandoor_front", "tandoor_side", "tandoor_top"]):
        im = Image.open(os.path.join(BLOCK_DIR, n + ".png")).resize((16 * scale, 16 * scale), Image.NEAREST)
        bsheet.alpha_composite(im, (8 + i * (16 * scale + 8), 8))
    bsheet.save(os.path.join(os.path.dirname(os.path.abspath(__file__)), "preview_blocks.png"))
    print(len(ITEMS), "item textures,", 3, "block textures written")
    print(" ".join(names))


main()
